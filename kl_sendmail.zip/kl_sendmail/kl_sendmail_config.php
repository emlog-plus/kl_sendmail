<?php
define('KL_MAIL_SMTP','mail.qq.com'); //smtp服务器

define('KL_MAIL_PORT','25'); //smtp端口

define('KL_MAIL_SENDEMAIL','858280596@qq.com'); //发信邮箱

define('KL_MAIL_PASSWORD','123456a'); //发信密码

define('KL_MAIL_TOEMAIL',''); //收信邮箱

define('KL_MAIL_SENDTYPE','0');

define('KL_IS_SEND_MAIL','Y');

define('KL_IS_REPLY_MAIL','Y');

define('KL_IS_TWITTER_MAIL','Y');
?>